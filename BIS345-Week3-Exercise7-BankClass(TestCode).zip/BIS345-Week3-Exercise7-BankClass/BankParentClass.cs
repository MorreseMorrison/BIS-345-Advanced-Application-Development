﻿using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class BankParentClass
{
	public BankParentClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}
