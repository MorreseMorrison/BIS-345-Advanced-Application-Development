﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BIS345_Week3_Exercise7_BankClass
{
    public partial class Form1 : Form
    {


        
         protected class BankAccount {

           string First_Name;
           // string Middle_Name;
           // string Last_Name;
           // string Home_Address;
           // string Account_Number;
           // int Social_Security_Number;
           // int Debit_Card_Number;
           // double Total_Balance;
           // double Savings_Account_Interest_Rate;
           // double Account_Minimum;





        }

        class CheckingAccount : BankAccount{


            public string First_Name { get; set; }



        }

        class SavingsAccount : BankAccount{



        }

       


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


            SavingsAccount Morrese_David_Morrison_Savings_Account = new SavingsAccount();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CheckingAccount Morrese_David_Morrison_Checking_Account = new CheckingAccount {First_Name = "Morrese"};

            textBox1.Text = Morrese_David_Morrison_Checking_Account.First_Name.ToString();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
