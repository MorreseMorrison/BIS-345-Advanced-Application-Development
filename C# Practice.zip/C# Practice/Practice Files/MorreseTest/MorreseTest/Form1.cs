﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorreseTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {   //Practice 1 Selecting One Item From List Box Then Displaying It
            // Get the currently selected item in the ListBox.
            //string curItem = listBox1.SelectedItem.ToString();
            //MessageBox.Show(curItem);


            




        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Practice 2 Selecting Multiple Items And Utilizing A Button To Print Values To A Label
            label1.Text = "";
            foreach(object shakeshack in listBox1.SelectedItems)
            {
                label1.Text += (label1.Text == "" ? "" : ",") + shakeshack.ToString();
            }



        }
    }
}
